<?php
 $pdo = new PDO("mysql:host=localhost;dbname=fil_rouge_eole", "root", "root");
 ?>