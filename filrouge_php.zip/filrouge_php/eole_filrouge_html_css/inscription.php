<?php
session_start();
require 'db.php';



// isset permet de verifier l'éxistance de quelque chose, $_POST['mess'] != '' permet de verifier que la zone de texte mess n'est pas vide et permet d'obliger de remplir le champ


if(isset ($_POST['username']) && $_POST['username'] != '' && isset ($_POST['password']) && $_POST['password'] != '' && isset ($_POST['tel']) && isset ($_POST['e_mail']) && $_POST['e_mail'] != '' ){ 
    $donnees = [//on stocke le contenu des différentes zones de texte
        'username' => $_POST['username'],
        'password' => $_POST['password'],
        'tel' => $_POST['tel'],
        'e_mail' => $_POST['e_mail'],
    ];

    $requete = $pdo->prepare(//on prepare la base de données à recuperer des informations
        "INSERT INTO users (`username`, `password`,`tel`, `e_mail`) VALUES ( :username, :password,:tel, :e_mail)"//on souhaite ici inserer dans la base de donnée les valeurs associées (on définit le lieu puis la valeur se stockera)
    );

    $ajout = $requete->execute($donnees);//on stocke dans la base de données


    if ($ajout) { //si les valeurs ont été stockés
        header('Location: accueil.php?compte_crée');

    } else{ //si ce n'est pas le cas
        header('Location: accueil.php');
        // echo 'ajout échoué';//ce message s'affichera
    }
}
    
    ?>