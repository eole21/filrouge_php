<!DOCTYPE html>
<html>
<head>
	<title>page sondage</title>
	<link rel="stylesheet"  href="css/style.css">
</head>
<body class="body2">
<header class="header2">
	
	<button><a href="./ko.php">#KOH-LONTA</a></button>
	<button><a href="./mars.php">#LES_MARSEILLAIS</a></button>

</header>

<nav class="nav2">
	<p class="B">Bienvenue dans la maison des secrets</p>
	<h1>#SECRET STORY</h1>
	<p class="q">Question</p>
	<p class="e">"Il y aura t'il une nouvelle saison de Secret Story ?"</p>
	
<div class="reponse">
	<button>OUI</button>
	<button>NON</button>
</div>
	
	



</nav>
	

</body>
</html>