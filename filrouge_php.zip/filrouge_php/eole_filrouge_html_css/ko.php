<?php
session_start();
require 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title>page sondage</title>
	<link rel="stylesheet"  href="css/style.css">
</head>
<body class="body2">
<header class="header2">
	
	<button><a href="./ss.php">#SECRET_STORY</a></button>
	<button><a href="./mars.php">#LES_MARSEILLAIS</a></button>

</header>

<nav class="nav2">
	<p class="B">Bienvenue dans l'aventure</p>
	<h1>#KOH-LONTA</h1>
	<p class="q">Question</p>
	<p class="e">"Est-ce Claude qui a gagner Kohlanta 2019"</p>
	
<div class="reponse">
	<form action="" method="POST">
		<input type="radio" name="rp_possible" value="rep1">
		<label for="demo2-a">Oui</label>
		<input type="radio" name="rp_possible" value="rep2">
		<label for="demo2-b">Non</label>
		<br><br>
	
		<input type="submit" name="insert" value="insert data">
	</form>

	<?php
	if(isset($_POST['insert']))
	{
		$mes_rp = $_POST['rp_possible'];
		$query = $pdo->prepare("INSERT INTO `reponses_sondage` (`rp_choisie`) VALUES ('$mes_rp')");
		$pdo->beginTransaction();
		$query->execute(array(
			":rp_possible" => $mes_rp));
			$pdo->commit();
			$pdo->null;
			header("Location:ko.php");
			exit;

		

		// $data = $query->fetch();

		// if($query)
		// {
		// 	echo'c_est bon';
		// }else{
		// 	echo'c_est pas bon';
		// }
	}
	?>



	<button>OUI</button>
	<button>NON</button>
</div>
	
	



</nav>
	

</body>
</html>