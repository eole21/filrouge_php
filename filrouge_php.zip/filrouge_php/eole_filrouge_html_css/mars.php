<!DOCTYPE html>
<html>
<head>
	<title>page sondage</title>
	<link rel="stylesheet"  href="css/style.css">
</head>
<body class="body2">
<header class="header2">
	
	<button><a href="./ko.php">#KOH-LONTA</a></button>
	<button><a href="./ss.php">#SECRET STORY</a></button>

</header>

<nav class="nav2">
	<p class="B">Bienvenue dans la maison des Marseillais</p>
	<h1>#LES_MARSEILLAIS</h1>
	<p class="q">Question</p>
	<p class="e">"Qui va ganger la saison 6 ?"</p>
	
<div class="reponse">
	<button>Maeva </button>
	<button>Nicolas</button>
</div>
	
	



</nav>
	

</body>
</html>