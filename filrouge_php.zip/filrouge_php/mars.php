<?php
session_start();
require 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title>page sondage</title>
	<link rel="stylesheet"  href="css/style.css">
</head>
<body class="body2">
<header class="header2">
	
	<button><a href="./ko.php">#KOH-LONTA</a></button>
	<button><a href="./ss.php">#SECRET STORY</a></button>
	<button><a href="./welcom.html">Bienvenue</a></button>


</header>

<nav class="nav2">
	<p class="B">Bienvenue dans la maison des Marseillais</p>
	<h1>#LES_MARSEILLAIS</h1>
	<p class="q">Question</p>
	<p class="e">"Qui va ganger la saison 6 ?"</p>
	
	
	
<div class="reponse">
	<form action="" method="POST">
		<input type="radio" name="rp_possible" value="rep1">
		<label for="demo2-a">Maeva</label>
		<input type="radio" name="rp_possible" value="rep2">
		<label for="demo2-b">Nicolas</label>
		<br><br>
	
		<input type="submit" name="insert" value="SEND">
	</form>

	<?php
	if(isset($_POST['insert']))
	{
		$mes_rp = $_POST['rp_possible'];
		$query = $pdo->prepare("INSERT INTO `reponses_sondage` (`rp_choisie`) VALUES ('$mes_rp')");
		$pdo->beginTransaction();
		$query->execute(array(
			":rp_possible" => $mes_rp));
			$pdo->commit();
			$pdo->null;
			header("Location:mars.php");
			exit;
		
		
	}

	
	?>



	
</div>
	
	



</nav>
	

</body>
</html>