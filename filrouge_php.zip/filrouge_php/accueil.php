<?php
session_start();
require 'db.php';
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>accueil</title>
	<link rel="stylesheet"  href="css/style.css">
</head>
<body>


	<h1>Inscrivez vous</h1>
  <form action="inscription.php" method="POST">
  <p><i>Complétez le formulaire. Les champs marqués par </i><em>*</em> sont <em>obligatoires</em></p>
  <fieldset>
    <legend>Contact</legend>
      <label for="nom">Prenom Nom <em>*</em></label>
      <!-- //placeholder: indication grisée 
      //required: il faut renseigner le champs sinon la validation est bloquée
      //autofocus: le curseur est positionné dans cette case au chargement de la page -->
      <input id="nom" placeholder="Prenom Nom" name="username" autofocus="" required><br>

      <label>Mot de passe<em>*</em></label>
      <input type="password" placeholder="Entrer un mot de passe" name="password" required>
  <br>
      <label for="telephone">Portable</label>
      <!-- // type="tel": permet de basculer le clavier sur un smartphone
      // pattern: expression régulière à vérifier pour pouvoir valider -->
      <input id="telephone" type="tel" name="tel" placeholder="06xxxxxxxx" pattern="06[0-9]{8}"><br>
      <label for="email">Email <em>*</em></label>
      <input id="email" type="email" name="e_mail" placeholder="prenom.nom@gmail.com" required pattern="[a-zA-Z]*.[a-zA-Z]*@gmail.com"><br>
  </fieldset>
  <input type="submit" id='submit' value='SUBMIT'>
  

  <?php
                if(isset($_GET['erreur_ins'])){
                    $err_ins = $_GET['erreur_ins'];
                    if($err_ins==1){
                        echo "<p style='color:red'>Ce nom d'utilisateur est déja pris</p>";
                    }
                        

                        if($err_ins==2){
                            echo "<p style='color:red'>Les champs sont vides</p>";
                        }
                }
                ?>
</form>
  <p>OU</p>
  
  	<fieldset>



	<div id="container">
            <!-- zone de connexion -->
            
            <form action="connect.php" method="POST">
                <h2>Connexion</h2>
                
                <label><b>Prenom et Nom de l'utilisateur</b></label>
                <input type="text" placeholder="Entrer le nom d'utilisateur" name="username" required>

                <label><b>Mot de passe</b></label>
                <input type="password" placeholder="Entrer le mot de passe" name="password" required>

                <input type="submit" id='submit' value='LOGIN'>
                
                <?php
                if(isset($_GET['erreur_con'])){
                    $err_con = $_GET['erreur_con'];
                    if($err_con==1){
                        echo "<p style='color:red'>Erreur identification</p>";
                    }
                        

                        if($err_con==2){
                            echo "<p style='color:red'>Les champs sont vides</p>";
                    }
                }
                ?>
            </form>
        </div>
</fieldset>
</body>
</html>