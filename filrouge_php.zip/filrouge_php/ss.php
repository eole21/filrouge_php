<?php
session_start();
require 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title>page sondage</title>
	<link rel="stylesheet"  href="css/style.css">
</head>
<body class="body2">
<header class="header2">
	
	<button><a href="./ko.php">#KOH-LONTA</a></button>
	<button><a href="./mars.php">#LES_MARSEILLAIS</a></button>
	<button><a href="./welcom.html">Bienvenue</a></button>

</header>

<nav class="nav2">
	<p class="B">Bienvenue dans la maison des secrets</p>
	<h1>#SECRET STORY</h1>
	<p class="q">Question</p>
	<p class="e">"Il y aura t'il une nouvelle saison de Secret Story ?"</p>
	
	
	
<div class="reponse">
	<form action="" method="POST">
		<input type="radio" name="rp_possible" value="rep1">
		<label for="demo2-a">Oui</label>
		<input type="radio" name="rp_possible" value="rep2">
		<label for="demo2-b">Non</label>
		<br><br>
	
		<input type="submit" name="insert" value="SEND">
	</form>

	<?php
	if(isset($_POST['insert']))
	{
		$mes_rp = $_POST['rp_possible'];
		$query = $pdo->prepare("INSERT INTO `reponses_sondage` (`rp_choisie`) VALUES ('$mes_rp')");
		$pdo->beginTransaction();
		$query->execute(array(
			":rp_possible" => $mes_rp));
			$pdo->commit();
			$pdo->null;
			header("Location:ss.php");
			exit;
		
		
	}

	
	?>



	
</div>
	
	



</nav>
	

</body>
</html>