<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css2/app.css">  
    <title>tchat</title>
</head>
<body>
  <header>
   
  </header>
  <main>
  <a href="welcom.html">Bienvenue</a>
    <h1>N'hésitez pas à commenter vos résultats du sondage </h2>
    <section class="chat">
        <div class="messages"></div>
        <div class="user-inputs">
        <form action="result_tchat.php?task=write" method="POST">
            <input type="text" name="author" id="author" placeholder="votre pseudo ?">
            <input type="text" id="content" name="content" placeholder="Ecris ton commentaire !">
            <button type="submit" id="valid">Envoyer</button>
        </form>
        </div>
    </section>
  </main>
  <script src="js/app.js"></script>
</body>
</html>