-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : Dim 13 déc. 2020 à 18:40
-- Version du serveur :  5.7.24
-- Version de PHP : 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `fil_rouge_eole`
--

-- --------------------------------------------------------

--
-- Structure de la table `reponses_sondage`
--

CREATE TABLE `reponses_sondage` (
  `id` int(11) NOT NULL,
  `rp_choisie` varchar(220) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `reponses_sondage`
--

INSERT INTO `reponses_sondage` (`id`, `rp_choisie`) VALUES
(1, 'rep1'),
(3, 'rep1'),
(4, 'rep1'),
(5, 'rep2'),
(6, 'rep2'),
(7, 'rep1');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `e_mail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `tel`, `e_mail`) VALUES
(1, 'root', 'root', '', ''),
(2, 'test1', 'test1', '', ''),
(3, 'test2', 'test2', '', ''),
(4, 'test3', 'test3', '', ''),
(5, 'test4', 'test4', '', ''),
(6, 'jklmm,n', 'fdghjhkl', '', 'gfhjkj.gfh@polytechnique.edu'),
(7, 'fghj', 'gfhjk', '0624798351', 'lolita.spon@polytechnique.edu'),
(8, 'dona', 'mama', '0654712837', 'dona.denkey@polytechnique.edu'),
(9, 'mama', 'cita', '', 'mama.cita@polytechnique.edu');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `reponses_sondage`
--
ALTER TABLE `reponses_sondage`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `reponses_sondage`
--
ALTER TABLE `reponses_sondage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
